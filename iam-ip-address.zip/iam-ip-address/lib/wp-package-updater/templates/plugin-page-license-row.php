<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
} ?>
<tr class="plugin-update-tr active installer-plugin-update-tr">
	<td colspan="4" class="plugin-update colspanchange">
		<div class="notice inline notice-warning notice-alt">
			<?php echo $form; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</div>
	</td>
</tr>
