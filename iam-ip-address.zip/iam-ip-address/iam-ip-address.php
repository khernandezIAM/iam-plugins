<?php
/*
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * Dashboard. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * this starts the plugin.
 *
 * @link:		https://iamupdateserver.org/
 * @since             	1.0.1
 * @package           	iam-ip-address
 *
 * @wordpress-plugin
 * Plugin Name:       IAM IP Address
 * Plugin URI:        https://iamupdateserver.org/
 * Description:       Simple plugin for displaying user IP using a shortcode.
 * Version:           1.0.6
 * Author:            Kiley Hernandez
 * Author URI:        https://iamupdateserver.org/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       iam-terms-and-conditions
 * Domain Path:       /languages
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/* ================================================================================================ */
/*                                  WP Packages Update Server                                         */
/* ================================================================================================ */

/**
* Uncomment the section below to enable updates with WP Packages Update Server.
*
* WARNING - READ FIRST:
*
* Before deploying the plugin or theme, make sure to change the following values in wppus.json:
* - server          => The URL of the server where WP Packages Update Server is installed ; required
* - requireLicense  => Whether the package requires a license ; true or false ; optional
*
* Also change $prefix_updater below - replace "prefix" in this variable's name with a unique prefix
*
**/

/** Enable updates **/
/* phpcs:ignore Squiz.PHP.CommentedOutCode.Found
*/
require_once __DIR__ . '/lib/wp-package-updater/class-wp-package-updater.php';

$iamip_updater = new WP_Package_Updater(
	wp_normalize_path( __FILE__ ),
	0 === strpos( __DIR__, WP_PLUGIN_DIR ) ? wp_normalize_path( __DIR__ ) : get_stylesheet_directory()
);


/* ====================================DISPLAY USER IP============================================= */ 
function get_user_ip() {
if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
//check ip from share internet
$ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
//to check ip is pass from proxy
$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
$ip = $_SERVER['REMOTE_ADDR'];
}
return apply_filters( 'wpb_get_ip', $ip );
}
 
add_shortcode('show_ip', 'get_user_ip');

/* ===================================END DISPLAY USER IP========================================== */