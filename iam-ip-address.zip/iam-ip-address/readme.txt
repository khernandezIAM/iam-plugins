=== IAM IP Address ===
Contributors: kileyhernandez
Donate link: https://iamupdateserver.org/
Tags: iam ip, ip display
Requires at least: 4.9.8
Tested up to: 4.9.8
Requires PHP: 7.4
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Diplays the users IP using a shortcode.

== Description ==

Diplays the users IP using a shortcode.

== Dummy Section ==

An extra, dummy section.

== Installation ==

Download, install and activate

== Changelog ==
<p>04/24/2024: 4.0.3 Testing Update Server</p>

<p>04/23/2024: 4.0.2 Testing Update Server</p>

<p>04/23/2024: 4.0.1 - Initial testing and release</p>