=== IAM Shortcodes for Communicators ===
Contributors: @khernandez, @scottdeluzio, @frogerme
Tags: iam shortcodes
Requires at least: 5.5
Tested up to: 5.9.1
Requires PHP: 7.2
Stable tag: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Useful IAM Related Shortcodes for IAM Communicators Only.

== Description ==
Library of IAM Specific shortcodes to help populate your website. The release 1.0.6 now has a shortcode selector on the main editor.  It also list ALL shortocdes installed on your site.  All IAM Shortocdes are listed with IAM in the name. A big thank you @frogerme and @scottdeluzio for your code work, and to Joe Jackman from IAM Local 1202 for helping with this project.

Some of the IAM specific Shortcodes include.

 - IAM Terms and Privacy Statement (using the default IAM text.
 - Our IAM YouTube playlist embed (most current year)
 - IAM Timeline from GoIAM.org chronicling the history of the IAM.
 - iMail News RSS (Generic)
 - IAM Legislative News RSS (Generic)

== Installation ==
Current Installation

1. Verify the installation. Determine if your install is in the Plugins Directory or the MU Directory.  You can verify this by going to plugins and looking for the IAM Shortcodes for Communciators plugin.

2. MU Installation - Contact me to switch out the installation from the MU to your primary directory.  From there you will get updates as usual.

3. Normal Plugin Installation. If you have an old version of this plugin (pre V1.0.3) then you will need to delete the plugin and re-install with the new plugin.  Once installed, activate.

New Installation

1. Download the plugin from the repository on iamDivpress.org.

2. Upload plugin to the plugin directory.

3. Activate.

== Screenshots ==
<p>1. Add your IAM Shortcode to any page or post using the build in shortcode drop down.</p>
<p><a href="https://iamdivpress.org/wp-content/uploads/2021/07/iam_sc_01.jpg" target="_blank"><img src="https://iamdivpress.org/wp-content/uploads/2021/07/iam_sc_01-480.jpg"></a></p>

== Changelog ==
02/23/2021 - 2.3.4 - Maintenance Release.

02/14/2021 - 2.3.3 - Added NFFE News.

02/09/2021 - 2.3.2 - Added TCU Union News.

02/09/2021 - 2.3.1 - Kiley messed up fix.

02/09/2021 - 2.3 - Added News from Canada IAMAW.ca

02/09/2021 - 2.2.9 - Added iMail Page (Previous was for Widget)

10/08/2021 - 2.2.8 - Code updates.

10/08/2021 - 2.2.7 - Code updates.

10/08/2021 - 2.2.6 - Code updates.

08/30/2021 - 2.2.5 - Code cleanup and plugin maintenance. No additions.

07/13/2021 - 2.2.4 - Code cleanup and plugin maintenance.

07/13/2021 - 2.2.3 - Code cleanup and plugin maintenance.

07/13/2021 - 2.2.2 - Code cleanup and plugin maintenance.

10/08/2020 - 2.2.1 - Add iMail Signup Up Form. If you need to change the height of the iMail sign up you can add the height by adding the shortcode just like this: [IMAILSIGNUP height="200"]

10/08/2020 - 2.2.0 - Corrected the default IAM Policy embed. If you need to change the dimensions you can do so by adding the shortcode just like this you can change either value: [IAMPOLICY width="100%" height="900"]

10/08/2020 - 2.1.9 - Compatability declaration for WP 5.5.1.

07/21/2020 - 2.1.8 - Additional code maintenance.

07/21/2020 - 2.1.7 - Plugin code cleanup and other admin functions.

07/20/2020 - 2.1.6 - Block admin bar for all users except admin. 

06/23/2020 - 2.1.5 - Updated the IAM Journal Bookcase Embed Code.

06/18/2020 - 2.1.4 - Display User IP Address

04/06/2020 - 2.1.2 - Wordpress Compatability

02/21/2020 - 2.1.2 - Cleaned up code and plugin and file headers.

02/21/2020 - 2.1.1 - Adjusted version requirements.

02/21/2020 - 2.1.0 - Fixed IAM Policy shortcode.

04/25/2019 - 2.0.9 - Fixed iMail Widget to exclude images for better formatting.

03/28/2019 - 2.0.8 - Added the IAM Social Wall

03/27/2019 - 2.0.7 - Added Activate Live Podcast

03/19/2019 - 2.0.6 - Add IAM Calendar.

03/19/2019 - 2.0.5 - New feeds for iMail for Pages and iMail for Widgets (large and small).

03/14/2019 - 2.0.4 - Maintenance Release.

03/13/2019 - 2.0.3 - Added IAM Action Center (Legislative).

03/12/2019 - 2.0.2 - Added IAM Journal Bookcase.

03/11/2019 - 2.0.1 - Added IAM Organizing Form.

03/04/2019 - 2.0.0 - Stable Release.

03/04/2019 - 1.0.19 - Maintenance Release Only.

03/04/2019 - 1.0.18 - Maintenance Release Only.

03/01/2019 - 1.0.17 - Maintenance Release Only.

02/28/2019 - 1.0.16 - Maintenance Release Only.

02/28/2019 - 1.0.15 - Maintenance Release Only.

02/28/2019 - 1.0.14 - Maintenance Release Only.

02/27/2019 - 1.0.13 - Maintenance Release Only.

01/23/2019 - 1.0.12 - Maintenance Release Only.

01/23/2019 - 1.0.11 - Maintenance Release Only.

1/23/2019 - 1.0.10 - Maintenance Release Only.

01/23/2019 - 1.0.9 - Maintenance Release Only.

01/23/2019 - 1.0.8 - Maintenance Release Only.

01/23/2019 - 1.0.6 - Add new dropdown for ALL shortcodes in the main editing window.

11/16/2018 - 1.0.5 - Added IAM Acticvate Live playlist for your pages.

11/08/2018 - 1.0.4 - Maintenance Release - Code cleanup and optimization.

11/08/2018 - 1.0.3 - Fixed the iMail signup shortcode. Added the Journal Bookcase, and made this plugin updateable via WordPress dashboard. (See the release notes below)

02/01/2017 - 1.0.2 - Added iMail signup shortcode. This is shortcode is ideal for a widget area however it could be used on any page.

02/01/2017 - 1.0.1 - Official release - Includes shortcodes for Privacy Policy, IAM YouTube, IAM Timeline, iMail Feed, Legislative News Feed.

01/30/2017 - 1.0.0 - Beta Release - Includes shortcodes of Privacy Policy.

Updates - Release Notes

--11/08/2018--

With version 1.0.3 (11/08/2018) the IAM Shortcodes for Communicators plugin can be updated like any other plugin. When the plugin changes you will receive a notification on your WordPress dashboard (update channel). Download and update as normal.

 - *Note: If you have this plugin installed in the Must Use section and would like to replace it for this version for the updates, send me an email and tell me to SWAP the IAM Shortcodes plugin.

 - *Note: Do not delete the shortcodes from your pages during the update. As long as you complete the process above you will not need to reset your shortcodes.

== Upgrade Notice ==
Just install and enjoy. I will be adding more features when they are available.