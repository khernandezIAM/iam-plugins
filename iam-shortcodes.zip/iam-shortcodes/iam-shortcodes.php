<?php
/*
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * Dashboard. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * this starts the plugin.
 *
 * @link:		https://www.iamdivpress.org
 * @since            	1.0.1
 * @package           	iam-shortcodes
 *
 * @wordpress-plugin
 * Plugin Name:       IAM Shortcodes for Communicators
 * Plugin URI:        https://iamupdateserver.org/
 * Description:        Library of IAM Specific shortcodes to help populate your website. The release 1.0.6 now has a shortcode selector on the main editor.  It also list ALL shortocdes installed on your site.  All IAM Shortocdes are listed with IAM in the name. A big thank you @frogerme and @scottdeluzio for your code work, and to Joe Jackman from IAM Local 1202 for helping with this project.  <a href="https://iamdivpress.org/developer/documents/iam-shortcode-instructions.html" target="_blank">List of Shortcodes & Uses</a>.
 * Version:           2.3.4
 * Author:            Kiley Hernandez
 * Author URI:        https://iamupdateserver.org/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       iam-terms-and-conditions
 * Domain Path:       /languages
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/* ================================================================================================ */
/*                                  WP Packages Update Server                                         */
/* ================================================================================================ */

/**
* Uncomment the section below to enable updates with WP Packages Update Server.
*
* WARNING - READ FIRST:
*
* Before deploying the plugin or theme, make sure to change the following values in wppus.json:
* - server          => The URL of the server where WP Packages Update Server is installed ; required
* - requireLicense  => Whether the package requires a license ; true or false ; optional
*
* Also change $prefix_updater below - replace "prefix" in this variable's name with a unique prefix
*
**/

/** Enable updates **/
/* phpcs:ignore Squiz.PHP.CommentedOutCode.Found
*/
require_once __DIR__ . '/lib/wp-package-updater/class-wp-package-updater.php';

$iamshortcodes_updater = new WP_Package_Updater(
	wp_normalize_path( __FILE__ ),
	0 === strpos( __DIR__, WP_PLUGIN_DIR ) ? wp_normalize_path( __DIR__ ) : get_stylesheet_directory()
);


/* ================================================================================================ */

function iam_shortcodes_run() {}
add_action( 'plugins_loaded', 'iam_shortcodes_run', 10, 0 );

/* ====================================BEGIN IAM SHORTCODES======================================== */

/* ====================================IAM POLICY================================================== */

function iamuapolicy_iframe( $atts ) {

	// Attributes
	$atts = shortcode_atts(
		array(
			'height' => '900',
			'width' => '100%',
		),
		$atts,
		'iampolicy'
	);

	// Return custom iframe code

	return '<html><iframe src="https://iamdivpress.org/developer/documents/iam-privacy-user.html" style="border:0px #ffffff none;" name="policy" scrolling="auto" frameborder="0" marginheight="0px" marginwidth="0px" height="' . $atts['height'] . '" width="' . $atts['width'] . '" allowfullscreen></iframe></html>';

}
add_shortcode( 'IAMPOLICY', 'iamuapolicy_iframe' );

/* ====================================YOU TUBE IFRAME============================================= */

function iamyotuube_iframe() {
 return '<html><iframe src="https://www.youtube.com/embed/videoseries?list=PLJ6SJCpDBWOoNBD9OmIEGqWC-IKlyKmJX" style="border:0px #ffffff none;" name="youtube" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="480px" width="100%" allowfullscreen></iframe></html>';
}
add_shortcode('IAMYOUTUBE', 'iamyotuube_iframe');

/* ====================================IAM TIMELINE================================================ */

function iamtimeline_iframe() {
 return '<html><iframe src="https://cdn.knightlab.com/libs/timeline3/latest/embed/index.html?source=1OaD8UoynArcs1EUIrGPHEo0OCQ11rsDb2KJHqmXhMAQ&amp;font=Default&amp;lang=en&amp;hash_bookmark=true&amp;initial_zoom=2&amp;height=650" width="100%" height="650" frameborder="0"></iframe></html>';
}
add_shortcode('IAMTIMELINE', 'iamtimeline_iframe');

/* ====================================IAM IMAIL=================================================== */

function imailpage_iframe() {
 return '<html><!-- start feedwind code --> <script type="text/javascript" src="https://feed.mikle.com/js/fw-loader.js" data-fw-param="104692/"></script> <!-- end feedwind code --></html>';
}
add_shortcode('IMAILPAGE', 'imailpage_iframe');

/* ====================================IAM IMAIL WIDGET =========================================== */

function imailwidget_iframe() {
 return '<html><!-- start feedwind code --> <script type="text/javascript" src="https://feed.mikle.com/js/fw-loader.js" data-fw-param="105005/"></script> <!-- end feedwind code --></html>';
}
add_shortcode('IMAILWIDGET', 'imailwidget_iframe');

/* ====================================IAM IMAIL PAGES =========================================== */

function imailpages_iframe() {
 return '<html><!-- start feedwind code --> <script type="text/javascript" src="https://feed.mikle.com/js/fw-loader.js" data-fw-param="104692/"></script> <!-- end feedwind code --></html>';
}
add_shortcode('IMAILPAGES', 'imailpages_iframe');

/* ====================================CANADA NEWS =========================================== */

function canadanews_iframe() {
 return '<html><!-- start feedwind code --> <script type="text/javascript" src="https://feed.mikle.com/js/fw-loader.js" data-fw-param="152870/"></script> <!-- end feedwind code --></html>';
}
add_shortcode('CANADANEWS', 'canadanews_iframe');

/* ====================================TCU UNION NEWS =========================================== */

function tcuunionnews_iframe() {
 return '<html><!-- start feedwind code --> <script type="text/javascript" src="https://feed.mikle.com/js/fw-loader.js" data-fw-param="152872/"></script> <!-- end feedwind code --></html>';
}
add_shortcode('TCUUNIONNEWS', 'tcuunionnews_iframe');

/* ====================================IAM LEG NEWS================================================ */

function legislativenews_iframe() {
 return '<html><!-- start feedwind code --> <script type="text/javascript" src="https://feed.mikle.com/js/fw-loader.js" data-fw-param="104694/"></script> <!-- end feedwind code --></html>';
}
add_shortcode('LEGISLATIVENEWS', 'legislativenews_iframe');

/* ====================================NFFE NEWS NEWS================================================ */

function nffenews_iframe() {
 return '<html><!-- start feedwind code --> <script type="text/javascript" src="https://feed.mikle.com/js/fw-loader.js" data-fw-param="153005/"></script> <!-- end feedwind code --></html>';
}
add_shortcode('NFFENEWS', 'nffenews_iframe');

/* ====================================IAM ORGANIZING============================================== */

function organizingform_iframe() {
 return '<html><iframe src="//www.goiam.org/gfembed/?f=2" width="100%" height="500" frameBorder="0" class="gfiframe"></iframe>
<script src="//www.goiam.org/wp-content/plugins/gravity-forms-iframe-develop/assets/scripts/gfembed.min.js" type="text/javascript"></script></html>';
}
add_shortcode('ORGANIZINGFORM', 'organizingform_iframe');

/* ====================================IAM JOURNAL BOOKCASE======================================== */

function journalbookcase_iframe() {
 return '<html><iframe src="https://iamdocs.org/bookcase/lkxz" style="border:0px #ffffff none;" name="journal-bookcase" scrolling="no" frameborder="0" marginheight="0px" marginwidth="0px" height="600px" width="100%" allowfullscreen></iframe></html>';
}
add_shortcode('JOURNALBOOKCASE', 'journalbookcase_iframe');

/* ====================================IAM ACTION CENTER=========================================== */

function legislativeactioncenter_iframe() {
return '<html><iframe src="https://www.goiam.org/forms/action-center-for-communications-plugin/#/" style="border:0px #ffffff none;" name="actioncenter" scrolling="auto" frameborder="0" marginheight="0px" marginwidth="0px" height="960px" width="100%" allowfullscreen></iframe></html>';
}
add_shortcode('ACTIONCENTER', 'legislativeactioncenter_iframe');

/* ====================================IAM CALENDAR================================================ */

function iamcalendar_iframe() {
return '<html><!-- start feedwind code --> <script type="text/javascript" src="https://feed.mikle.com/js/fw-loader.js" data-fw-param="104736/"></script> <!-- end feedwind code --></html>';
}
add_shortcode('IAMCALENDAR', 'iamcalendar_iframe');

/* ====================================IAM PODCAST+================================================ */

function activatelive_podcast_iframe() {
return '<html><!-- start feedwind code --> <script type="text/javascript" src="https://feed.mikle.com/js/fw-loader.js" data-fw-param="105698/"></script> <!-- end feedwind code --></html>';
}
add_shortcode('ACTIVATELIVEPODCAST', 'activatelive_podcast_iframe');

/* ====================================IAM SOCIAL WALL============================================= */

function iam_socalwall_iframe() {
return '<html><script src="https://assets.juicer.io/embed.js" type="text/javascript"></script>
<link href="https://assets.juicer.io/embed.css" media="all" rel="stylesheet" type="text/css" />
<ul class="juicer-feed" data-feed-id="iamaw"></ul></iframe></html>';
}
add_shortcode('IAMSOCIALWALL', 'iam_socalwall_iframe');

/* ====================================IMAIL SIGNUP=============================================== */
function imail_signup_form( $atts ) {

	// Attributes
	$atts = shortcode_atts(
		array(
			'height' => '900',
		),
		$atts,
		'imailsignup'
	);

	// Return custom iframe code
	return '<html><iframe src="//www.goiam.org/gfembed/?f=23" width="100%" height="' . $atts['height'] . '" frameBorder="0" class="gfiframe"></iframe>
	<script src="//www.goiam.org/wp-content/plugins/gravity-forms-iframe-develop/assets/scripts/gfembed.min.js" type="text/javascript"></script></html>';

}
add_shortcode( 'IMAILSIGNUP', 'imail_signup_form' );


/* ====================================IAM REMOVE ADMIN============================================ */

add_action('after_setup_theme', 'remove_admin_bar');
 
function remove_admin_bar() {
if (!current_user_can('administrator') && !is_admin()) {
  show_admin_bar(false);
}
}

/* ====================================DISPLAY USER IP============================================= */ 
function get_the_user_ip() {
if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
//check ip from share internet
$ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
//to check ip is pass from proxy
$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
$ip = $_SERVER['REMOTE_ADDR'];
}
return apply_filters( 'wpb_get_ip', $ip );
}
 
add_shortcode('show_ip', 'get_the_user_ip');

/* ===================================END DISPLAY USER IP========================================== */

/* ====================================SHORTCODE LISTER============================================ */

add_action('plugins_loaded', 'shortcode_lister_load_textdomain');
function shortcode_lister_load_textdomain() {
	load_plugin_textdomain( 'wod', false, dirname( plugin_basename(__FILE__) ) . '/lang/' );
}

/*
 * Includes for Shortcode Lister Plugin by Scott DeLuzio
 */
if ( ! defined( 'SHORTCODE_LISTER' ) ) {
    define( 'SHORTCODE_LISTER', __FILE__ );
}
if( ! defined( 'SHORTCODE_LISTER_PLUGIN_DIR' ) ) {
 	define( 'SHORTCODE_LISTER_PLUGIN_DIR', dirname( __FILE__ ) );
}
if( ! defined( 'SHORTCODE_LISTER_PLUGIN_URL' ) ) {
	define( 'SHORTCODE_LISTER_PLUGIN_URL', plugins_url( '', __FILE__ ) );
}
if( ! defined( 'SHORTCODE_LISTER_PLUGIN_BASENAME' ) ) {
	define( 'SHORTCODE_LISTER_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
}
if( ! defined( 'SHORTCODE_LISTER_VERSION' ) ) {
	define( 'SHORTCODE_LISTER_VERSION', '2.0.0' );
}
	
if(is_admin()) {
	include( SHORTCODE_LISTER_PLUGIN_DIR . '/includes/scripts-styles.php' );
	include( SHORTCODE_LISTER_PLUGIN_DIR . '/includes/get-shortcodes.php' );
	include( SHORTCODE_LISTER_PLUGIN_DIR . '/includes/shortcode-lister-settings.php' );
}
/* ====================================END SHORTCODE LISTER======================================== */